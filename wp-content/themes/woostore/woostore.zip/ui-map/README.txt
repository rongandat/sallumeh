
jquery-ui-map version 2.0


Documentation: http://code.google.com/p/jquery-ui-map/wiki/Overview

Examples: http://code.google.com/p/jquery-ui-map/wiki/Examples

Demo: http://code.google.com/p/jquery-ui-map/

Issues: http://code.google.com/p/jquery-ui-map/issues/list

Discuss at: http://groups.google.com/group/jquery-ui-map-discuss

Packed with http://dean.edwards.name/packer/


CHANGES:

2011-04-15 Renamed the method clear to clearMarkers.

